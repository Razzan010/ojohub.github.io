
<style>
    html, body {
        max-width: 100%;
        overflow-x: hidden;
    }
</style>

          <?php
              include 'topbar2_stores-mobile.php';         
            ?> 

<body style="background:#F4F4F4;">

    
<?php
    if (isset($_SESSION['customer_email'])) {
	$customer_email=$_SESSION['customer_email'];
    }
?>






<!-------------------- Body Starts-------------------------->


   
                    
<div style="min-width:50;padding-bottom:65px;">





















<?php

$customer_email=$_SESSION['customer_email'];
$get_customer="select * from customers where customer_email='$customer_email'";
$run_cust=mysqli_query($con,$get_customer);
$row_cust=mysqli_fetch_array($run_cust);

$customer_email=$row_cust['customer_email'];
$customer_id=$row_cust['customer_id'];
$customer_name=$row_cust['customer_name'];
$customer_phone=$row_cust['customer_phone'];

$customer_dist=$row_cust['customer_dist'];
$customer_city=$row_cust['customer_city'];
$customer_street=$row_cust['customer_street'];
$customer_ward=$row_cust['customer_ward'];
?>

<?php

$customer_email=$_SESSION['customer_email'];
$get_product="select * from products where customer_email='$customer_email'";
$run_product=mysqli_query($con,$get_product);
$row_product=mysqli_fetch_array($run_product);

$product_dist=$row_product['location_dist'];
$product_city=$row_product['location_city'];
$product_street=$row_product['location_street'];
$product_ward=$row_product['location_ward'];


?>
<!-------------------------------------------------------->


<!--------------------------------------------->
<div style="background:white;">
<div class="" style="padding-top: 10px;padding-left: 5%;width: 95%;">

<!--Upload  formxxx-->
<div class="box-header"><!--box-header start-->
		<h4 class="text-muted " style="color: green; font-weight: bold;"> Updating Product</h4>
		
		
		<!----------------Delete Button--------------------->
<div style="padding-bottom: ;padding-left: ;float:right;">
	<?php
		echo "<button style= 'font-weight:bold;'><a href='delete_product.php?product_id=$product_id'  onclick='return check_delete()' style= 'color:red;'>Delete this Product</a></button>";
	?>

	<script type="text/javascript">
		function check_delete()
		{
			return confirm('Are you sure you want to delete this Article ?');
		}
	</script>
</div>

<!----------------------------------------------->
</div><!--box-header end-->
<div style="width:100%;height:1px;background-color:#A9B8D1;margin-top:10px;margin-bottom:10px;">
</div> 











<!-------------------------------------------------------->


<?php

$customer_email=$_SESSION['customer_email'];
$get_customer="select * from customers where customer_email='$customer_email'";
$run_cust=mysqli_query($con,$get_customer);
$row_cust=mysqli_fetch_array($run_cust);

$customer_email=$row_cust['customer_email'];
$customer_id=$row_cust['customer_id'];
$customer_name=$row_cust['customer_name'];
$customer_phone=$row_cust['customer_phone'];

$customer_dist=$row_cust['customer_dist'];
$customer_city=$row_cust['customer_city'];
$customer_street=$row_cust['customer_street'];
$customer_ward=$row_cust['customer_ward'];
?>

<?php

$customer_email=$_SESSION['customer_email'];
$get_product="select * from products where customer_email='$customer_email'";
$run_product=mysqli_query($con,$get_product);
$row_product=mysqli_fetch_array($run_product);

$product_dist=$row_product['location_dist'];
$product_city=$row_product['location_city'];
$product_street=$row_product['location_street'];
$product_ward=$row_product['location_ward'];


?>
<!-------------------------------------------------------->


<!--------------------------------------------->
<div style="background:white;">
<div class="" style="padding-top: 10px;">

              

<div style="width:100%;height:1px;background-color:#A9B8D1;margin-top:10px;margin-bottom:10px;">
</div> 



<form action="update_product.php" method="post" class="form-group" enctype="multipart/form-data">
    
<?php
	if (isset($_GET['product_id'])) {
	$product_id=$_GET['product_id'];
    $get_product="select * from products where product_id='$product_id'";
    $run_product=mysqli_query($con,$get_product);	
	$row_product=mysqli_fetch_array($run_product);
    $product_title=$row_product['product_title'];	
    $product_desc=$row_product['product_desc'];	
    $product_price=$row_product['product_price'];	

    $category_id=$row_product['category_id'];
    $count_num_digits=strlen($category_id);
    
        if($count_num_digits==5){
            $category_id_new='0'.$category_id;
        }else{
            $category_id_new=$category_id;            
        }
	}	
	?>

<?php
    $get_category="select * from category where category_id='$category_id_new'";
    $run_category=mysqli_query($con,$get_category);	
	$row_category=mysqli_fetch_array($run_category);
	
	$category=$row_category['category'];    
	$sub_category=$row_category['sub_category'];
	$type=$row_category['type']; 
?>    
 
<div class="form-group col-md-12">
    	<i class='fa fa-pencil-square'></i>
    	<label>Product Category </label>
    	<!-- <a href="select_categories.php" style="float:right;">Select Category </a> -->
    	<br>
    	<div class="col-md-4">
    	    Category :
    	    <input style="border: 2px solid #19BC15 ;color:orange;font-weight:bold;" value="<?php echo $category?>" type="text" name="category" class="form-control" style="font-weight: bold;" required="">
    	</div>
        
        <div class="col-md-4">
            Sub-category :
            <input style="border: 2px solid #19BC15 ;color:orange;font-weight:bold;" value="<?php echo $sub_category?>" type="text" name="category" class="form-control" style="font-weight: bold;" required="" >
        </div>
        
        <div class="col-md-4">
            Type :
            <input style="border: 2px solid #19BC15 ;color:orange;font-weight:bold;" value="<?php echo $type?>" type="text" name="category" class="form-control" style="font-weight: bold;">  
        </div>



   
    <div class="" style="display:none;">

        <label>Category Id</label>
        <input style="border: 2px solid #19BC15 ;color:orange;font-weight:bold;" value="<?php echo $category_id ?>" type="text" name="category_id" class="form-control" style="font-weight: bold;"  >
    </div>
    
</div>    

    

<div class="form-group">
	<label>
    	<i class='fa fa-dot-circle-o'></i>
    	Selling/Buying
	</label>
	<br>
	
	<i class='fa fa-credit-card'></i>
	I am Selling.<input type="checkbox" name="product_selling" value="Yes" style="margin-left: 80px;">
	<br>
	<i class='fa fa-money'></i>					
	I am Buying.<input type="checkbox" name="product_buying" value="Yes" style="margin-left: 82px;">
						
		<?php 
			if(isset($_POST['product_selling'])){
				$product_selling="Selling";      
			}else{
				$product_selling=" ";      
			}
		?> 
		
		<?php 
			if(isset($_POST['product_buying'])){
			    $product_buying="Buying";      
			}else{
				$product_buying=" ";      
			}
		?> 	
		

</div> 


<br>
<div class="form-group">
	<i class='fa fa-pencil-square'></i>
	<label>Product Title</label>
	<input style="border: 2px solid #19BC15 ;" type="text" name="product_title" class="form-control" value="<?php echo $product_title; ?>" style="font-weight: bold;" required="" >
</div>




<div class="col-md-12 form-group">					
	<i class='fa fa-gg'></i>
	<label>Price</label>
	<br>
	<div class="col-md-2" style="">
	Rs:
    </div>
    <div class="col-md-5">	
    	<input style="border: 2px solid #19BC15 ;margin-top:5px;" type="number" name="product_price" value="<?php echo $product_price; ?>" id="num1" class="form-control" style="width: 30%;" required="" >
    </div>	
    <div class="col-md-5">
        <select name="color" id="color" class="form-control"  style="border: 2px solid #19BC15 ;margin-top:5px;">
            <option value="Fixed" selected>Fixed</option>            
            <option value="Negotiable">Negotiable</option>

            <option value="As a gift">As a Gift</option>
        </select> 
        
        <?php
            $color = filter_input(INPUT_POST, 'color', FILTER_SANITIZE_STRING);
        ?>
        <?php  $price_type=$color ?> 
     </div>    
</div>



<div>
	<i class='fa fa-pencil-square-o'></i>
	<label>Product Description</label>
	<textarea  type="" name="product_desc" value="<?php echo $product_desc; ?>" class="form-control" style="resize: none; height: 15%; width: 100%; border: 2px solid #19BC15 ;" required="">	
    </textarea>	
</div>

<br>
<br>
<div class="form-group">
	<i class='fa fa-picture-o'></i>
	<label>Product Images (Max. 3 Images) </label>
<br>
	
	<P style="border: 1px solid; color: green;">Required
	    <input style="border: 2px solid #19BC15 ;" type="file" name="image1" class="form-control" placeholder="required" style="padding-left: 15px;" required="">
	</P>	
							<br>
	<P style="border: 1px solid; color: green;">Optional
		<input style="border: 2px solid #19BC15 ;" type="file" name="image2" class="form-control" placeholder="optional" style="padding-left: 15px;">
	</p>	
							<br>
	<P style="border: 1px solid; color: green;">Optional
		<input style="border: 2px solid #19BC15 ;" type="file" name="image3" class="form-control" placeholder="optional" style="padding-left: 15px;">
	</p>	
</div>


<br>

    
<label>	<i class='fa fa-map-marker'></i> Product Address </label>
<div style="width:100%;height:1px;background-color:#A9B8D1;margin-top:10px;margin-bottom:10px;">
</div>

<div class="form-group">
	<label>District</label>					
	<input style="border: 2px solid #19BC15 ;" autocomplete="off" type="text" name="product_dist_new" class="form-control" required="" value="<?php echo $customer_dist;  ?>" >			
</div>

<div class="form-group">
	<label>City</label>
	<input style="border: 2px solid #19BC15 ;" type="text" name="product_city_new" class="form-control" value="<?php echo $customer_city; ?> ">
</div>
<div class="form-group">
	<label>Street</label>
	<input style="border: 2px solid #19BC15 ;" type="text" name="product_street_new" class="form-control" value="<?php echo $customer_street; ?> " >
</div>
<div class="form-group">
	<label>Ward</label>
	<input style="border: 2px solid #19BC15 ;" type="text" name="product_ward_new" class="form-control" value="<?php echo $customer_ward; ?> "> 
</div>


<br>
<label><i class="fa fa-info-circle" aria-hidden="true"></i> Your Infos </label>
<br>
<div style="width:100%;height:1px;background-color:#A9B8D1;margin-top:10px;margin-bottom:10px;">
</div>

<div class="form-group">

	<label><i class="fa fa-envelope" aria-hidden="true"></i> Email</label>					
	<input style="border: 2px solid #19BC15 ;" autocomplete="off" type="email" name="reg_email" class="form-control" required="" value="<?php echo $customer_email;  ?>" disabled="" >			
</div>

<div class="form-group">

	<label><i class="fa fa-user" aria-hidden="true"></i> Name</label>					
	<input style="border: 2px solid #19BC15 ;" autocomplete="off" type="" name="reg_email" class="form-control" required="" value="<?php echo $customer_name;  ?>" disabled="" >			
</div>

<div class="form-group">

	<label><i class="fa fa-phone-square" aria-hidden="true"></i> Telephone Number </label>					
	<input style="border: 2px solid #19BC15 ;" autocomplete="off" type="" name="reg_email" class="form-control" required="" value="<?php echo $customer_phone;  ?>">			
</div>


<div style="width:100%;height:1px;background-color:#A9B8D1;margin-top:10px;margin-bottom:10px;">
</div> 

<div class="form-group" style="text-align: center;">
	<button  class="login-btn-login-page " name="submit" style="font-weight: bold;width: auto;color: white;">
			Update Product               
	</button>
</div>
</form>




<style>
    .login-btn-login-page{
  background: #19BC15; 
  height:40px; 
  width:90px; 
  border:none;
  border-radius: 5px; 
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
</style>

<?php
if (isset($_POST['submit'])) {  

   
    $product_dist_new=$_POST['product_dist_new'];
    $product_city_new=$_POST['product_city_new'];
    $product_street_new=$_POST['product_street_new'];
    $product_ward_new=$_POST['product_ward_new'];
    
    $product_title=$_POST['product_title'];
    $category_id=$_POST['category_id'];
    $post_date = date("Y.m.d");
    
    $product_price=$_POST['product_price'];
    $product_desc=$_POST['product_desc'];
    
        $image1=$_FILES['image1']['name'];
		$image1_tmp=$_FILES['image1']['tmp_name'];


		$image2=$_FILES['image2']['name'];
		$image2_tmp=$_FILES['image2']['tmp_name'];

		$image3=$_FILES['image3']['name'];
		$image3_tmp=$_FILES['image3']['tmp_name'];		




		    $sel_cart="select * from products where customer_email='$customer_email'";
		    $run_customer=mysqli_query($con,$sel_cart);
		    $check_cart=mysqli_num_rows($run_customer);

		move_uploaded_file($image1_tmp, "product_images/$image1");
		move_uploaded_file($image2_tmp, "product_images/$image2");
		move_uploaded_file($image3_tmp, "product_images/$image3");
		
		
    
    $insert_customer="insert into products(customer_id,customer_name,customer_email,customer_phone,location_dist,location_city,location_street,location_ward,product_title,category_id,post_date,product_price,price_type,product_desc,product_delivery,product_selling,product_buying,product_image1) values('$customer_id','$customer_name','$customer_email','$customer_phone','$product_dist_new','$product_city_new','$product_street_new','$product_ward_new','$product_title','$category_id','$post_date','$product_price','$price_type','$product_desc','$delivery','$product_selling','$product_buying','$image1')";
    $run_customer=mysqli_query($con,$insert_customer);
}    

?>













</div>

</div>



</div>   


          <?php
              include 'bottom_bar-mobile.php';         
            ?>

</body>











